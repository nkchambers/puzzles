﻿using System;
using System.Collections.Generic;

namespace puzzles
{
    class Program
    {
        static void Main(string[] args)
        {
            //------------------------------------RANDOM ARRAY FUNCTION---------------------------------------
            Random rand = new Random();
            int [] numsArray = new int[10];
            int min = 25, max = 5, sum = 0;
            List<string> name = new List<string>();

            for (int i = 0; i < numsArray.Length; i++) 
            {
                numsArray[i] = rand.Next(5, 25);
                Console.WriteLine(numsArray[i]);
            }
            for (int j = 0; j < numsArray.Length; j++) 
            {
                if (numsArray[j] > max)
                    max = numsArray[j];
                else if (numsArray[j] < min)
                    min = numsArray[j];
                
                sum += numsArray[j];
            }

            Console.WriteLine($"The smallest value is: {min}");
            Console.WriteLine($"The largest value is: {max}");
            Console.WriteLine($"The sum of all values is: {sum}");

            //Calling Functions Inside Main 
            TossCoin();
            TossMultipleCoins(10);
            name = Names();

        }
        
        //--------------------------------------COIN FLIP FUNCTION---------------------------------------
        public static string TossMultipleCoins(int num) {
            Random rand = new Random();
            int result = 0;
            string value = "";
            double heads = 0, ratio = 0;

            Console.WriteLine($"Tossing {num} Coin(s)!");
            
            for(int i = 1; i <= num; i++) {
                result = rand.Next(2);
                if (result == 0) {
                    value = "Heads";
                    Console.WriteLine($"Coin Flip: {value}");
                    heads++;
                }
                else {
                    value = "Tails";
                    Console.WriteLine($"Coin Flip: {value}");
                }
            }
            ratio = heads/num;
            Console.WriteLine($"Heads = {heads} / Total: {num}");
            return ratio;
        }
//--------------------------------------COIN FLIP FUNCTION---------------------------------------
        public static string TossCoin() {
            Random rand = new Random();
            int result = 0;
            string value = "";

            Console.WriteLine("Tossing a Coin!");

            result = rand.Next();
                if (result == 0) {
                    value = "Heads";
                    Console.WriteLine($"Coin Flip: {value}");
                }
                else {
                    value = "Tails";
                    Console.WriteLine($"Coin Flip: {value}");
                }

            return value;

        }

        public static List<string> Names() {
            List<string> names = new List<string>();
            Random rand = new Random();

            names.Add("Todd");
            names.Add("Tiffany");
            names.Add("Charlie");
            names.Add("Geneva");
            names.Add("Sydney");

            names = Shuffle(names);

            for(int i = 0; i < names.Count; i++) {
                Console.WriteLine("-" + names[i]);
            }
            for(int j = 0; j < names.Count;) {
                string temp = "";
                temp = names[j];
                if (temp.Length > 5) {
                    names.Remove(temp);
                }
                else {
                    j++;
                }
            }

            Console.WriteLine("-----------------------------Showing Names With Less Than 5 Characters Below---------------------------------");

            for (int i = 0; i < names.Count; i++) {
                
                Console.WriteLine("-" + names[i]);
            }
        }
    }
}
